from django.contrib import admin
from django.urls import path
from restaurant.core import views
urlpatterns=[
 path('admin/',admin.site.urls), path('',views.home,name='home'), path('menu/',views.menu,name='menu'),
 path('order/',views.order,name='order'), path('support/',views.support,name='support'),
 path('thanks/',views.thanks,name='thanks'),
]
