from django.shortcuts import render, redirect
from .models import MenuItem,Order,OrderItem,ContactMessage

def home(request):
    featured=MenuItem.objects.filter(available=True,featured=True)[:6]
    if not featured: featured=MenuItem.objects.filter(available=True)[:6]
    return render(request,'core/home.html',{'featured':featured})

def menu(request):
    category=request.GET.get('category','all')
    items=MenuItem.objects.filter(available=True)
    if category!='all': items=items.filter(category=category)
    return render(request,'core/menu.html',{'items':items,'category':category})

def order(request):
    if request.method=='POST':
        ids=request.POST.getlist('item_id')
        selected=[]
        for item_id in ids:
            try:
                item=MenuItem.objects.get(id=item_id,available=True)
                qty=max(1,int(request.POST.get(f'quantity_{item_id}', '1')))
                selected.append((item,qty))
            except (MenuItem.DoesNotExist,ValueError,TypeError): pass
        if selected:
            o=Order.objects.create(customer_name=request.POST.get('name',''),phone=request.POST.get('phone',''),address=request.POST.get('address',''),note=request.POST.get('note',''))
            for item,qty in selected: OrderItem.objects.create(order=o,menu_item=item,quantity=qty,price=item.price)
            return redirect('thanks')
    return render(request,'core/order.html',{'items':MenuItem.objects.filter(available=True)})

def support(request):
    if request.method=='POST':
        ContactMessage.objects.create(name=request.POST.get('name',''),phone=request.POST.get('phone',''),message=request.POST.get('message',''))
        return redirect('thanks')
    return render(request,'core/support.html')

def thanks(request): return render(request,'core/thanks.html')
