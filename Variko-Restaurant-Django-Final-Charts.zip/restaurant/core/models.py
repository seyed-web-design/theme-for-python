from django.db import models
class MenuItem(models.Model):
    CATEGORY_CHOICES=[('main','غذای اصلی'),('pizza','پیتزا'),('burger','برگر'),('drink','نوشیدنی'),('dessert','دسر')]
    name=models.CharField(max_length=120)
    description=models.TextField(blank=True)
    price=models.PositiveIntegerField()
    category=models.CharField(max_length=20,choices=CATEGORY_CHOICES,default='main')
    image=models.URLField(blank=True)
    featured=models.BooleanField(default=False)
    available=models.BooleanField(default=True)
    def __str__(self): return self.name
class Order(models.Model):
    STATUS=[('new','جدید'),('preparing','در حال آماده‌سازی'),('ready','آماده ارسال'),('done','تحویل شده')]
    customer_name=models.CharField(max_length=120)
    phone=models.CharField(max_length=30)
    address=models.TextField()
    note=models.TextField(blank=True)
    status=models.CharField(max_length=20,choices=STATUS,default='new')
    created_at=models.DateTimeField(auto_now_add=True)
    def total(self): return sum(i.subtotal() for i in self.items.all())
    def __str__(self): return f'سفارش #{self.id} - {self.customer_name}'
class OrderItem(models.Model):
    order=models.ForeignKey(Order,related_name='items',on_delete=models.CASCADE)
    menu_item=models.ForeignKey(MenuItem,on_delete=models.PROTECT)
    quantity=models.PositiveIntegerField(default=1)
    price=models.PositiveIntegerField()
    def subtotal(self): return self.price*self.quantity
class ContactMessage(models.Model):
    name=models.CharField(max_length=120)
    phone=models.CharField(max_length=30,blank=True)
    message=models.TextField()
    created_at=models.DateTimeField(auto_now_add=True)
    answered=models.BooleanField(default=False)
    def __str__(self): return self.name


class SalesReset(models.Model):
    reset_at = models.DateTimeField()

    def __str__(self):
        return f'ریست فروش: {self.reset_at}'
