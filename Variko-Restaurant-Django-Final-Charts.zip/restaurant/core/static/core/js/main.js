document.querySelectorAll('input[type=checkbox]').forEach(c=>c.addEventListener('change',()=>{c.closest('.order-row')?.classList.toggle('selected',c.checked)}));
