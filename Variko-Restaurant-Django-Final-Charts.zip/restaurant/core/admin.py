from datetime import datetime, time
import json

from django.contrib import admin, messages
from django.shortcuts import redirect
from django.urls import path, reverse
from django.utils import timezone
from django.utils.html import format_html

from .models import MenuItem, Order, OrderItem, ContactMessage, SalesReset


@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'price', 'featured', 'available')
    list_filter = ('category', 'available', 'featured')
    search_fields = ('name',)


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ('price', 'subtotal_display')
    fields = ('menu_item', 'quantity', 'price', 'subtotal_display')

    @admin.display(description='جمع')
    def subtotal_display(self, obj):
        return f'{obj.subtotal():,} تومان' if obj.pk else '-'


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer_link', 'phone', 'status', 'total_display', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('customer_name', 'phone', 'address')
    inlines = [OrderItemInline]
    change_list_template = 'admin/core/order/change_list.html'

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                'sales-reset/',
                self.admin_site.admin_view(self.reset_sales),
                name='core_order_sales_reset',
            ),
        ]
        return custom + urls

    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}
        now = timezone.localtime(timezone.now())
        current_tz = timezone.get_current_timezone()
        today_start = timezone.make_aware(
            datetime.combine(now.date(), time.min),
            current_tz,
        )

        reset_obj = SalesReset.objects.order_by('-reset_at').first()
        reset_at = reset_obj.reset_at if reset_obj else None
        if reset_at:
            reset_local = timezone.localtime(reset_at)
            start = max(today_start, reset_at)
        else:
            reset_local = None
            start = today_start

        end = timezone.now()
        orders = list(
            Order.objects.filter(created_at__gte=start, created_at__lte=end)
            .prefetch_related('items__menu_item')
        )

        # Line chart: number of orders in each hour of today.
        hourly_orders = {hour: 0 for hour in range(24)}
        # Column chart: quantity sold for each menu item + its revenue.
        food_stats = {}
        sales_total = 0

        for order in orders:
            local_created = timezone.localtime(order.created_at)
            hourly_orders[local_created.hour] += 1
            for order_item in order.items.all():
                item_id = order_item.menu_item_id
                if item_id not in food_stats:
                    food_stats[item_id] = {
                        'id': item_id,
                        'name': order_item.menu_item.name,
                        'quantity': 0,
                        'revenue': 0,
                    }
                food_stats[item_id]['quantity'] += order_item.quantity
                food_stats[item_id]['revenue'] += order_item.subtotal()
                sales_total += order_item.subtotal()

        # Include all menu items so the admin can add any food to the chart,
        # even if it has zero sales since the last reset.
        all_menu_items = MenuItem.objects.order_by('name')
        food_chart = []
        for item in all_menu_items:
            stat = food_stats.get(item.id, {
                'id': item.id,
                'name': item.name,
                'quantity': 0,
                'revenue': 0,
            })
            food_chart.append(stat)

        extra_context.update({
            'food_chart_json': json.dumps(food_chart, ensure_ascii=False),
            'hourly_orders_json': json.dumps(
                [{'hour': f'{hour:02d}', 'orders': hourly_orders[hour]} for hour in range(24)],
                ensure_ascii=False,
            ),
            'sales_total': sales_total,
            'sales_order_count': len(orders),
            'sales_reset_at': reset_local,
            'sales_reset_url': reverse('admin:core_order_sales_reset'),
        })
        return super().changelist_view(request, extra_context=extra_context)

    @admin.display(description='مشتری')
    def customer_link(self, obj):
        url = reverse('admin:core_order_change', args=[obj.pk])
        return format_html('<a href="{}">{}</a>', url, obj.customer_name or 'بدون نام')

    @admin.display(description='مبلغ کل')
    def total_display(self, obj):
        return f'{obj.total():,} تومان'

    def reset_sales(self, request):
        if request.method != 'POST':
            return redirect('admin:core_order_changelist')
        SalesReset.objects.update_or_create(
            pk=1,
            defaults={'reset_at': timezone.now()},
        )
        self.message_user(
            request,
            'آمار فروش و نمودار سفارش‌ها از همین لحظه ریست شد. سفارش‌های قبلی حذف نمی‌شوند.',
            messages.SUCCESS,
        )
        return redirect('admin:core_order_changelist')


@admin.register(ContactMessage)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'answered', 'created_at')
    list_filter = ('answered',)
    search_fields = ('name', 'phone', 'message')


@admin.register(SalesReset)
class SalesResetAdmin(admin.ModelAdmin):
    list_display = ('reset_at',)
    readonly_fields = ('reset_at',)
